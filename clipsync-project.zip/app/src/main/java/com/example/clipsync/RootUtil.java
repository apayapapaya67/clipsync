package com.example.clipsync;

import java.io.BufferedReader;
import java.io.InputStreamReader;

// Pembantu untuk menjalankan perintah lewat root (su).
public class RootUtil {

    static final String LOGCAT_CMD = "logcat -T 1 -v brief -s ClipboardService";
    // tanda [l] supaya perintah pkill ini tidak mencocokkan dirinya sendiri
    static final String KILL_LOGCAT = "pkill -f '[l]ogcat -T 1 -v brief -s ClipboardService'";

    // null = belum dicek
    static volatile Boolean root = null;

    static synchronized boolean hasRoot() {
        if (root != null) return root.booleanValue();
        String out = run("id", 20000);
        root = Boolean.valueOf(out != null && out.contains("uid=0"));
        return root.booleanValue();
    }

    // Jalankan perintah lewat su. Mengembalikan output, atau null kalau timeout.
    static String run(final String cmd, long timeoutMs) {
        final StringBuilder sb = new StringBuilder();
        final Process[] holder = new Process[1];
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", cmd + " 2>&1"});
                    holder[0] = p;
                    BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()));
                    String l;
                    while ((l = r.readLine()) != null) {
                        sb.append(l).append('\n');
                    }
                    p.waitFor();
                } catch (Exception e) {
                    // su tidak ada / ditolak
                }
            }
        });
        t.start();
        try {
            t.join(timeoutMs);
        } catch (InterruptedException e) {
            // abaikan
        }
        if (t.isAlive()) {
            try {
                if (holder[0] != null) holder[0].destroy();
            } catch (Exception e) {
                // abaikan
            }
            return null;
        }
        return sb.toString();
    }

    // Beri izin yang dibutuhkan app lewat root (tanpa memulai ulang app)
    static String grantCmd(String pkg) {
        return "appops set " + pkg + " SYSTEM_ALERT_WINDOW allow; "
                + "pm grant " + pkg + " android.permission.SYSTEM_ALERT_WINDOW; "
                + "dumpsys deviceidle whitelist +" + pkg + "; "
                + "cmd appops set " + pkg + " RUN_ANY_IN_BACKGROUND allow; "
                + "cmd appops set " + pkg + " RUN_IN_BACKGROUND allow";
    }
}
