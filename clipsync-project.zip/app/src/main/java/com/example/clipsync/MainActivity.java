package com.example.clipsync;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends Activity {

    Handler h = new Handler(Looper.getMainLooper());
    TextView status;
    ArrayAdapter<String> adapter;
    Button btn;
    boolean leaving = false;

    Runnable tick = new Runnable() {
        @Override
        public void run() {
            refresh();
            h.postDelayed(this, 1000);
        }
    };

    int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        // Tandai: sinkron boleh jalan otomatis (mis. setelah HP restart)
        SharedPreferences sp = getSharedPreferences("cfg", MODE_PRIVATE);
        sp.edit().putBoolean("autostart", true).apply();

        startSync();
        buildUi();

        // Dengan root: beri izin overlay / baterai / background otomatis
        new Thread(new Runnable() {
            @Override
            public void run() {
                if (RootUtil.hasRoot()) {
                    RootUtil.run(RootUtil.grantCmd(getPackageName(), getApplicationInfo().uid), 20000);
                }
            }
        }).start();
    }

    void startSync() {
        Intent i = new Intent(this, ClipService.class);
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(24), dp(16), dp(16));

        TextView title = new TextView(this);
        title.setText("Clip Sync");
        title.setTextSize(24);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        status = new TextView(this);
        status.setTextSize(13);
        status.setPadding(0, dp(8), 0, dp(12));
        root.addView(status);

        TextView sub = new TextView(this);
        sub.setText("Perangkat tersedia");
        sub.setTextSize(16);
        sub.setTypeface(Typeface.DEFAULT_BOLD);
        sub.setPadding(0, 0, 0, dp(6));
        root.addView(sub);

        FrameLayout box = new FrameLayout(this);
        ListView list = new ListView(this);
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, new ArrayList<String>());
        list.setAdapter(adapter);
        box.addView(list, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        TextView empty = new TextView(this);
        empty.setText("Belum ada perangkat lain.\nPastikan kedua HP satu Wi-Fi dan Clip Sync aktif di keduanya.");
        empty.setTextSize(14);
        empty.setPadding(dp(8), dp(16), dp(8), 0);
        box.addView(empty, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT));
        list.setEmptyView(empty);

        root.addView(box, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        btn = new Button(this);
        btn.setText("Putuskan & Keluar");
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                disconnectAndExit();
            }
        });
        root.addView(btn, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        setContentView(root);
    }

    String lastPacketTxt() {
        long t = ClipService.lastPacketAt;
        if (t == 0) return "belum ada";
        long s = (android.os.SystemClock.elapsedRealtime() - t) / 1000;
        return s + " dtk lalu";
    }

    String mark(boolean ok) {
        return ok ? "✓" : "✗";
    }

    void refresh() {
        if (leaving) return;
        Boolean r = RootUtil.root;
        String rootTxt = (r == null) ? "memeriksa..." : (r.booleanValue() ? "ya" : "tidak");
        boolean overlay = true;
        boolean batt = true;
        if (Build.VERSION.SDK_INT >= 23) {
            overlay = Settings.canDrawOverlays(this);
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            batt = pm.isIgnoringBatteryOptimizations(getPackageName());
        }
        status.setText("Perangkat ini: " + ClipService.deviceName()
                + "\nService: " + (ClipService.alive ? "aktif" : "mati")
                + "\nRoot: " + rootTxt
                + "\nPemantau clipboard: " + ClipService.watcherMode
                + "\nIzin overlay: " + mark(overlay) + "    Bebas baterai: " + mark(batt)
                + "\nPaket terakhir diterima: " + lastPacketTxt()
                + "\nHELLO terkirim: " + ClipService.helloSent
                + "\nGalat terakhir: " + ClipService.lastError);

        ArrayList<String> peers = ClipService.snapshotPeers();
        adapter.clear();
        adapter.addAll(peers);
    }

    // Hentikan sinkron, bersihkan proses logcat, lalu tutup aplikasi sepenuhnya
    void disconnectAndExit() {
        if (leaving) return;
        leaving = true;
        btn.setEnabled(false);
        btn.setText("Memutuskan...");
        h.removeCallbacks(tick);

        getSharedPreferences("cfg", MODE_PRIVATE).edit().putBoolean("autostart", false).apply();

        ClipService.stopping = true;
        stopService(new Intent(this, ClipService.class));

        new Thread(new Runnable() {
            @Override
            public void run() {
                Boolean r = RootUtil.root;
                if (r != null && r.booleanValue()) {
                    RootUtil.run(RootUtil.KILL_LOGCAT, 3000);
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        finishAndRemoveTask();
                        h.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                android.os.Process.killProcess(android.os.Process.myPid());
                                System.exit(0);
                            }
                        }, 400);
                    }
                });
            }
        }).start();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!leaving) h.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        h.removeCallbacks(tick);
    }
}
