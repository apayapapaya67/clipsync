package com.example.clipsync;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Set;

public class MainActivity extends Activity {

    Handler h = new Handler(Looper.getMainLooper());
    TextView status;
    ArrayAdapter<String> adapter;
    ArrayList<String> macs = new ArrayList<String>();   // sejajar dengan isi daftar; null = bukan Bluetooth
    Button btn;
    boolean leaving = false;

    Runnable tick = new Runnable() {
        @Override
        public void run() {
            refresh();
            h.postDelayed(this, 1000);
        }
    };

    int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        // Tandai: sinkron boleh jalan otomatis (mis. setelah HP restart)
        SharedPreferences sp = getSharedPreferences("cfg", MODE_PRIVATE);
        sp.edit().putBoolean("autostart", true).apply();

        startSync();
        buildUi();

        // Dengan root: beri izin overlay / baterai / background / jaringan otomatis
        new Thread(new Runnable() {
            @Override
            public void run() {
                if (RootUtil.hasRoot()) {
                    RootUtil.run(RootUtil.grantCmd(getPackageName(), getApplicationInfo().uid), 20000);
                }
            }
        }).start();
    }

    void startSync() {
        Intent i = new Intent(this, ClipService.class);
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(24), dp(16), dp(16));

        TextView title = new TextView(this);
        title.setText("Clip Sync");
        title.setTextSize(24);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        status = new TextView(this);
        status.setTextSize(13);
        status.setPadding(0, dp(8), 0, dp(12));
        root.addView(status);

        TextView sub = new TextView(this);
        sub.setText("Perangkat tersedia");
        sub.setTextSize(16);
        sub.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(sub);

        TextView hint = new TextView(this);
        hint.setText("Ketuk HP Bluetooth untuk menghubungkan / memutuskan. Cukup dilakukan di salah satu HP; HP satunya menerima otomatis (app harus aktif di keduanya).");
        hint.setTextSize(12);
        hint.setPadding(0, dp(2), 0, dp(6));
        root.addView(hint);

        FrameLayout box = new FrameLayout(this);
        ListView list = new ListView(this);
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, new ArrayList<String>());
        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position < 0 || position >= macs.size()) return;
                String mac = macs.get(position);
                if (mac == null) return;
                if (mac.equals(ClipService.btTargetMac)) {
                    ClipService.btSetTarget(MainActivity.this, null);
                } else {
                    ClipService.btSetTarget(MainActivity.this, mac);
                }
                refresh();
            }
        });
        box.addView(list, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(box, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        btn = new Button(this);
        btn.setText("Putuskan & Keluar");
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                disconnectAndExit();
            }
        });
        root.addView(btn, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));

        setContentView(root);
    }

    String lastPacketTxt() {
        long t = ClipService.lastPacketAt;
        if (t == 0) return "belum ada";
        long s = (SystemClock.elapsedRealtime() - t) / 1000;
        return s + " dtk lalu";
    }

    String mark(boolean ok) {
        return ok ? "✓" : "✗";
    }

    void refresh() {
        if (leaving) return;
        Boolean r = RootUtil.root;
        String rootTxt = (r == null) ? "memeriksa..." : (r.booleanValue() ? "ya" : "tidak");
        boolean overlay = true;
        boolean batt = true;
        if (Build.VERSION.SDK_INT >= 23) {
            overlay = Settings.canDrawOverlays(this);
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            batt = pm.isIgnoringBatteryOptimizations(getPackageName());
        }
        status.setText("Perangkat ini: " + ClipService.deviceName()
                + "\nService: " + (ClipService.alive ? "aktif" : "mati")
                + "\nBluetooth: " + ClipService.btState
                + "\nRoot: " + rootTxt + "    Pemantau clipboard: " + ClipService.watcherMode
                + "\nIzin overlay: " + mark(overlay) + "    Bebas baterai: " + mark(batt)
                + "\nWi-Fi paket terakhir: " + lastPacketTxt() + "    HELLO terkirim: " + ClipService.helloSent
                + "\nGalat terakhir: " + ClipService.lastError);

        ArrayList<String> items = new ArrayList<String>();
        macs.clear();

        BluetoothAdapter ad = BluetoothAdapter.getDefaultAdapter();
        if (ad == null) {
            items.add("Bluetooth tidak tersedia di HP ini");
            macs.add(null);
        } else if (!ad.isEnabled()) {
            items.add("Bluetooth mati.\nNyalakan lalu sandingkan kedua HP di Pengaturan Bluetooth.");
            macs.add(null);
        } else {
            try {
                Set<BluetoothDevice> bonded = ad.getBondedDevices();
                if (bonded == null || bonded.isEmpty()) {
                    items.add("Belum ada HP yang tersandingkan.\nSandingkan dulu di Pengaturan Bluetooth.");
                    macs.add(null);
                } else {
                    for (BluetoothDevice d : bonded) {
                        String mac = d.getAddress();
                        String name = d.getName();
                        if (name == null) name = mac;
                        String st;
                        if (mac.equals(ClipService.btConnMac)) {
                            st = "● Terhubung • ketuk untuk putuskan";
                        } else if (mac.equals(ClipService.btTargetMac)) {
                            st = "Menghubungkan... • ketuk untuk batal";
                        } else {
                            st = "Tersandingkan • ketuk untuk hubungkan";
                        }
                        items.add("[Bluetooth] " + name + "\n" + st);
                        macs.add(mac);
                    }
                }
            } catch (Exception e) {
                items.add("Izin Bluetooth belum ada");
                macs.add(null);
            }
        }

        for (String p : ClipService.snapshotPeers()) {
            items.add("[Wi-Fi] " + p);
            macs.add(null);
        }

        adapter.clear();
        adapter.addAll(items);
    }

    // Hentikan sinkron, bersihkan proses logcat, lalu tutup aplikasi sepenuhnya
    void disconnectAndExit() {
        if (leaving) return;
        leaving = true;
        btn.setEnabled(false);
        btn.setText("Memutuskan...");
        h.removeCallbacks(tick);

        getSharedPreferences("cfg", MODE_PRIVATE).edit().putBoolean("autostart", false).apply();
        ClipService.btSetTarget(this, null);

        ClipService.stopping = true;
        stopService(new Intent(this, ClipService.class));

        new Thread(new Runnable() {
            @Override
            public void run() {
                Boolean r = RootUtil.root;
                if (r != null && r.booleanValue()) {
                    RootUtil.run(RootUtil.KILL_LOGCAT, 3000);
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        finishAndRemoveTask();
                        h.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                android.os.Process.killProcess(android.os.Process.myPid());
                                System.exit(0);
                            }
                        }, 400);
                    }
                });
            }
        }).start();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!leaving) h.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        h.removeCallbacks(tick);
    }
}
