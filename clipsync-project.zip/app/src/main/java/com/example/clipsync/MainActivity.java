package com.example.clipsync;

import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.widget.Toast;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        Intent i = new Intent(this, ClipService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);

        String msg = "Clip Sync aktif";
        Intent next = null;

        boolean readLogs = getPackageManager().checkPermission("android.permission.READ_LOGS", getPackageName())
                == PackageManager.PERMISSION_GRANTED;

        if (Build.VERSION.SDK_INT >= 23) {
            // 1) Bebas dari penghemat baterai
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (!pm.isIgnoringBatteryOptimizations(getPackageName())) {
                next = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:" + getPackageName()));
                msg = "Pilih IZINKAN agar tidak dimatikan sistem";
            }
            // 2) Izin tampil di atas app lain (untuk buka activity fokus dari background)
            else if (!Settings.canDrawOverlays(this)) {
                next = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                msg = "Aktifkan 'Tampil di atas app lain' untuk Clip Sync";
            }
        }

        if (next == null && !readLogs) {
            msg = "Belum ada izin READ_LOGS: kirim clipboard dari background belum jalan";
        }

        if (next != null) {
            try {
                startActivity(next);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
        finish();
    }
}
