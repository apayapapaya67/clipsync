package com.example.clipsync;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent in) {
        try {
            // Jangan jalan otomatis kalau terakhir kali sudah diputuskan manual
            if (!c.getSharedPreferences("cfg", Context.MODE_PRIVATE).getBoolean("autostart", true)) return;
            Intent i = new Intent(c, ClipService.class);
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
