package com.example.clipsync;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.Base64;
import android.widget.Toast;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class ClipService extends Service {
    static final int PORT = 47823;
    static final String P = "CS1"; // penanda protokol, paket lain diabaikan
    static final int MAX = 60000; // shortcut: batas 1 paket UDP, teks lebih panjang ditolak; pakai TCP kalau perlu
    // [:] supaya perintah pkill tidak ikut membunuh dirinya sendiri
    static final String KILL_WATCHER = "pkill -f 'ClipboardService[:]E'";
    static final String KILL_HELPER = "pkill -f 'ClipHelpe[r]'";
    static final String HELPER_CLASS = "com.example.clipsync.ClipHelper";
    static volatile ClipService instance;

    static class Dev { String id, name, ip; long seen; }

    final ConcurrentHashMap<String, Dev> found = new ConcurrentHashMap<String, Dev>();
    final ExecutorService out = Executors.newSingleThreadExecutor();
    ClipboardManager cm;
    NotificationManager nm;
    Handler main;
    DatagramSocket sock;
    WifiManager.MulticastLock lock;
    SharedPreferences prefs;
    String myId, myName;
    volatile String last = "";
    volatile boolean running = true;
    volatile Process watcher;
    // Jalur baca clipboard tanpa fokus: proses helper berjalan sebagai uid shell lewat root
    volatile Process helperProc;
    volatile boolean helperUp = false;      // helper berjalan
    volatile boolean helperOk = false;      // helper terbukti membaca salinan
    volatile boolean watchEnabled = true;   // pemantau logcat + ClipActivity (cadangan)
    volatile boolean watchRunning = false;
    volatile boolean listenerOn = false;
    volatile String helperInfo = "";

    final ClipboardManager.OnPrimaryClipChangedListener listener = new ClipboardManager.OnPrimaryClipChangedListener() {
        public void onPrimaryClipChanged() { clipChanged(); }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        main = new Handler(Looper.getMainLooper());
        try {
            prefs = getSharedPreferences("clip", MODE_PRIVATE);
            myId = prefs.getString("id", null);
            if (myId == null) {
                myId = UUID.randomUUID().toString().substring(0, 8);
                prefs.edit().putString("id", myId).apply();
            }
            myName = (Build.MANUFACTURER + " " + Build.MODEL).replace("|", " ");
            cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(new NotificationChannel("clip", "Clip Sync aktif", NotificationManager.IMPORTANCE_LOW));
                nm.createNotificationChannel(new NotificationChannel("pair", "Permintaan koneksi", NotificationManager.IMPORTANCE_HIGH));
            }
            startForeground(1, builder("clip").setContentTitle("Clip Sync aktif")
                    .setSmallIcon(android.R.drawable.ic_menu_share).build());

            lock = ((WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE)).createMulticastLock("clip");
            lock.acquire(); // sebagian HP membuang paket broadcast tanpa lock ini

            sock = new DatagramSocket(null);
            sock.setReuseAddress(true);
            sock.setBroadcast(true);
            sock.bind(new InetSocketAddress(PORT));

            cm.addPrimaryClipChangedListener(listener);
            listenerOn = true;
            new Thread(new Runnable() { public void run() { receive(); } }).start();
            new Thread(new Runnable() { public void run() { hello(); } }).start();
            startWatcher();
            new Thread(new Runnable() { public void run() { helperLoop(); } }).start();
        } catch (Exception e) {
            toast("Clip Sync error: " + e);
        }
    }

    Notification.Builder builder(String channel) {
        return Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, channel) : new Notification.Builder(this);
    }

    @Override
    public int onStartCommand(Intent i, int flags, int startId) {
        if (i != null && "ACCEPT".equals(i.getAction())) {
            String id = i.getStringExtra("id");
            setPaired(id);
            nm.cancel(id.hashCode());
            send(i.getStringExtra("ip"), "OK", "");
            toast("Terhubung dengan " + i.getStringExtra("name"));
        }
        return START_STICKY;
    }

    // Dipanggil saat clipboard berubah; di Android 10+ hanya berhasil kalau aplikasi sedang punya fokus
    void clipChanged() {
        try {
            ClipData c = cm.getPrimaryClip();
            if (c == null || c.getItemCount() == 0) return;
            CharSequence cs = c.getItemAt(0).coerceToText(this);
            if (cs == null) return;
            pushText(cs.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Kirim teks ke semua HP yang sudah terhubung
    void pushText(String t) {
        if (t == null || t.length() == 0 || t.equals(last)) return; // cegah kirim balik teks yang baru diterima
        last = t;
        for (Dev d : found.values()) if (isPaired(d.id)) send(d.ip, "CLIP", t);
    }

    void updateNotif(String text) {
        try {
            nm.notify(1, builder("clip").setContentTitle("Clip Sync aktif").setContentText(text)
                    .setSmallIcon(android.R.drawable.ic_menu_share).build());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    synchronized void startWatcher() {
        watchEnabled = true;
        if (watchRunning) return;
        watchRunning = true;
        new Thread(new Runnable() {
            public void run() {
                try { watchLogcat(); } finally { watchRunning = false; }
            }
        }).start();
    }

    void stopWatcher() {
        watchEnabled = false;
        Process w = watcher;
        if (w != null) w.destroy();
        new Thread(new Runnable() { public void run() { rootRun(KILL_WATCHER, false); } }).start();
    }

    // Helper terbukti jalan: pemantau logcat dan listener tidak diperlukan lagi (tidak ada lagi jendela yang muncul)
    void onHelperClip(String b64) {
        try {
            String t = new String(Base64.decode(b64, Base64.NO_WRAP), "UTF-8");
            if (!helperOk) {
                helperOk = true;
                updateNotif("Mode helper shell: tanpa jendela fokus");
                toast("Clip Sync: mode helper aktif, tidak perlu jendela mengambang");
                main.post(new Runnable() {
                    public void run() {
                        if (listenerOn && cm != null) { cm.removePrimaryClipChangedListener(listener); listenerOn = false; }
                    }
                });
                stopWatcher();
            }
            pushText(t);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Helper berhenti: kembali ke cara lama (listener + pemantau logcat)
    void fallbackToWatcher() {
        updateNotif("Helper berhenti, pakai pemantau logcat");
        main.post(new Runnable() {
            public void run() {
                if (!listenerOn && cm != null && running) { cm.addPrimaryClipChangedListener(listener); listenerOn = true; }
            }
        });
        startWatcher();
    }

    // Menjalankan ClipHelper sebagai uid shell (2000) lewat root; coba beberapa bentuk perintah su
    void helperLoop() {
        String cmd = "CLASSPATH=" + getPackageCodePath() + " exec app_process /system/bin " + HELPER_CLASS;
        String[][] variants = new String[][]{
                {"su", "2000", "-c", cmd},
                {"su", "shell", "-c", cmd},
                {"su", "-c", "su 2000 -c '" + cmd + "'"}
        };
        rootRun(KILL_HELPER, true); // sisa helper dari sesi sebelumnya
        int idx = 0;
        int fails = 0;
        while (running) {
            int r = runHelper(variants[idx]);
            if (!running) return;
            try {
                if (r == 1) {
                    fails = 0;
                    Thread.sleep(3000); // sempat jalan lalu berhenti: nyalakan lagi varian yang sama
                } else {
                    idx = (idx + 1) % variants.length;
                    fails++;
                    Thread.sleep(fails >= variants.length ? 30000 : 500);
                }
            } catch (InterruptedException e) {
                return;
            }
        }
    }

    // Mengembalikan 1 kalau helper sempat siap (uid 2000), 0 kalau gagal
    int runHelper(String[] v) {
        Process p = null;
        boolean ready = false;
        try {
            ProcessBuilder pb = new ProcessBuilder(v);
            pb.redirectErrorStream(true);
            p = pb.start();
            helperProc = p;
            final Process fp = p;
            final boolean[] gotReady = new boolean[1];
            Thread dog = new Thread(new Runnable() {
                public void run() {
                    try { Thread.sleep(8000); } catch (InterruptedException e) { return; }
                    if (!gotReady[0]) fp.destroy(); // tidak siap dalam 8 detik
                }
            });
            dog.start();
            BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream(), "UTF-8"));
            String line;
            while (running && (line = r.readLine()) != null) {
                if (line.startsWith("READY")) {
                    if (line.indexOf("uid=2000") >= 0) {
                        gotReady[0] = true;
                        ready = true;
                        helperUp = true;
                        updateNotif("Helper shell siap, menunggu salinan");
                    } else {
                        helperInfo = line; // bukan uid shell: izin baca clipboard tidak akan didapat
                        break;
                    }
                } else if (line.startsWith("C ")) {
                    onHelperClip(line.substring(2));
                } else if (!line.equals("H")) {
                    helperInfo = line.length() > 100 ? line.substring(0, 100) : line;
                }
            }
            dog.interrupt();
        } catch (Exception e) {
            helperInfo = String.valueOf(e);
        }
        try { if (p != null) p.destroy(); } catch (Exception e) { }
        helperUp = false;
        if (helperOk) { helperOk = false; fallbackToWatcher(); }
        if (!ready && running) updateNotif("Helper gagal: " + helperInfo);
        return ready ? 1 : 0;
    }

    // Root: satu shell memantau log "Denying clipboard access to <paket ini>" lalu langsung membuka ClipActivity
    void watchLogcat() {
        rootRun(KILL_WATCHER, true); // matikan pemantau sisa dari sesi sebelumnya supaya tidak dobel
        String pkg = getPackageName();
        String script = "logcat -v brief -T 1 -s ClipboardService:E | while read -r l; do "
                + "case \"$l\" in *\"access to " + pkg + ",\"*) "
                + "am start -n " + pkg + "/.ClipActivity >/dev/null 2>&1;; esac; done";
        boolean warned = false;
        while (running && watchEnabled) {
            try {
                watcher = Runtime.getRuntime().exec(new String[]{"su", "-c", script});
                watcher.waitFor(); // normalnya tidak pernah selesai selama service hidup
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (!running || !watchEnabled) return;
            if (!warned) { toast("Pemantau clipboard berhenti. Cek izin root Clip Sync."); warned = true; }
            try { Thread.sleep(10000); } catch (InterruptedException e) { return; }
        }
    }

    void rootRun(String cmd, boolean wait) {
        try {
            Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", cmd});
            if (wait) p.waitFor();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void send(final String ip, final String type, final String payload) {
        out.execute(new Runnable() {
            public void run() {
                try {
                    byte[] b = (P + "|" + type + "|" + myId + "|" + myName + "|" + payload).getBytes("UTF-8");
                    if (b.length > MAX) { toast("Teks terlalu panjang, tidak dikirim"); return; }
                    sock.send(new DatagramPacket(b, b.length, InetAddress.getByName(ip), PORT));
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    void hello() {
        while (running) {
            // shortcut: broadcast 255.255.255.255 kadang tidak sampai kalau salah satu HP jadi hotspot; pakai router Wi-Fi
            send("255.255.255.255", "HELLO", "");
            try { Thread.sleep(3000); } catch (InterruptedException e) { return; }
        }
    }

    void receive() {
        byte[] buf = new byte[65507];
        while (running) {
            try {
                DatagramPacket p = new DatagramPacket(buf, buf.length);
                sock.receive(p);
                String[] m = new String(p.getData(), 0, p.getLength(), "UTF-8").split("\\|", 5);
                if (m.length < 5 || !m[0].equals(P) || m[2].equals(myId)) continue; // abaikan paket asing & paket sendiri
                handle(m[1], m[2], m[3], p.getAddress().getHostAddress(), m[4]);
            } catch (Exception e) {
                if (!running) return;
                e.printStackTrace();
            }
        }
    }

    void handle(String type, String id, String name, String ip, final String payload) {
        Dev d = found.get(id);
        if (d == null) { d = new Dev(); d.id = id; found.put(id, d); }
        d.name = name;
        d.ip = ip; // IP selalu diperbarui, jadi tetap jalan walau router mengganti IP
        d.seen = System.currentTimeMillis();

        if (type.equals("PAIR")) {
            askPair(d);
        } else if (type.equals("OK")) {
            setPaired(id);
            toast("Terhubung dengan " + name);
        } else if (type.equals("UNPAIR") && isPaired(id)) {
            prefs.edit().remove("p_" + id).apply();
            toast("Diputus oleh " + name);
        } else if (type.equals("CLIP") && isPaired(id)) {
            last = payload;
            main.post(new Runnable() {
                public void run() { cm.setPrimaryClip(ClipData.newPlainText("sync", payload)); }
            });
        }
    }

    // Putus semua koneksi, kabari HP lawan yang sedang online
    void unpairAll() {
        for (Dev d : found.values()) if (isPaired(d.id)) send(d.ip, "UNPAIR", "");
        SharedPreferences.Editor e = prefs.edit();
        for (String k : prefs.getAll().keySet()) if (k.startsWith("p_")) e.remove(k);
        e.apply();
    }

    void askPair(Dev d) {
        Intent i = new Intent(this, ClipService.class).setAction("ACCEPT")
                .putExtra("id", d.id).putExtra("name", d.name).putExtra("ip", d.ip);
        PendingIntent pi = PendingIntent.getService(this, d.id.hashCode(), i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        nm.notify(d.id.hashCode(), builder("pair")
                .setContentTitle("Permintaan koneksi")
                .setContentText(d.name + " ingin terhubung")
                .setSmallIcon(android.R.drawable.ic_menu_share)
                .setAutoCancel(true)
                .addAction(android.R.drawable.ic_input_add, "Terima", pi)
                .build());
    }

    boolean isPaired(String id) { return prefs != null && prefs.getBoolean("p_" + id, false); }

    void setPaired(String id) { prefs.edit().putBoolean("p_" + id, true).apply(); }

    void toast(final String msg) {
        main.post(new Runnable() {
            public void run() { Toast.makeText(ClipService.this, msg, Toast.LENGTH_LONG).show(); }
        });
    }

    @Override
    public void onDestroy() {
        running = false;
        watchEnabled = false;
        instance = null;
        if (cm != null) cm.removePrimaryClipChangedListener(listener);
        out.shutdown();
        try { out.awaitTermination(500, TimeUnit.MILLISECONDS); } catch (InterruptedException e) { } // biar paket UNPAIR sempat terkirim
        if (sock != null) sock.close();
        if (lock != null && lock.isHeld()) lock.release();
        if (watcher != null) watcher.destroy();
        if (helperProc != null) helperProc.destroy();
        // tanpa ini logcat dan helper root tetap jalan setelah keluar
        new Thread(new Runnable() { public void run() { rootRun(KILL_WATCHER + "; " + KILL_HELPER, false); } }).start();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent i) { return null; }
}
