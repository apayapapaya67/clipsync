package com.example.clipsync;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Settings;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;

public class ClipService extends Service {

    static final int PORT = 47823;
    static final String KEY = "ganti-kode-ini:";
    static final int MAX = 60000;

    static final String ACTION_SEND = "com.example.clipsync.SEND";
    static final String EXTRA_TEXT = "t";

    ClipboardManager cm;
    Handler main;
    DatagramSocket sock;
    WifiManager.MulticastLock lock;
    WifiManager.WifiLock wifiLock;
    PowerManager.WakeLock wakeLock;
    Process logProc;

    volatile String last = "";
    volatile boolean running = false;
    volatile long ignoreUntil = 0;
    volatile long lastFocusTry = 0;

    ClipboardManager.OnPrimaryClipChangedListener listener = new ClipboardManager.OnPrimaryClipChangedListener() {
        @Override
        public void onPrimaryClipChanged() {
            try {
                ClipData d = cm.getPrimaryClip();
                if (d == null || d.getItemCount() == 0) return;
                CharSequence cs = d.getItemAt(0).coerceToText(ClipService.this);
                if (cs == null) return;
                handleLocalText(cs.toString());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        main = new Handler(Looper.getMainLooper());
        cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        running = true;

        Notification n = buildNotif();
        try {
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            } else {
                startForeground(1, n);
            }
        } catch (Exception e) {
            e.printStackTrace();
            try {
                startForeground(1, n);
            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }

        try {
            WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            lock = wm.createMulticastLock("clip");
            lock.setReferenceCounted(false);
            lock.acquire();
            wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "clipsync");
            wifiLock.setReferenceCounted(false);
            wifiLock.acquire();
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "klipsync:wake");
            wakeLock.setReferenceCounted(false);
            wakeLock.acquire();
        } catch (Exception e) {
            e.printStackTrace();
        }

        cm.addPrimaryClipChangedListener(listener);

        new Thread(new Runnable() {
            @Override
            public void run() {
                receive();
            }
        }).start();

        if (hasReadLogs()) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    watchLogcat();
                }
            }).start();
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_SEND.equals(intent.getAction())) {
            String t = intent.getStringExtra(EXTRA_TEXT);
            if (t != null) handleLocalText(t);
        }
        return START_STICKY;
    }

    // Teks baru dari clipboard HP ini -> kirim ke HP lain
    void handleLocalText(String t) {
        if (t == null) return;
        if (t.length() == 0 || t.length() > MAX) return;
        if (t.equals(last)) return;
        last = t;
        send(t);
    }

    boolean hasReadLogs() {
        return getPackageManager().checkPermission("android.permission.READ_LOGS", getPackageName())
                == PackageManager.PERMISSION_GRANTED;
    }

    boolean canDrawOverlay() {
        if (Build.VERSION.SDK_INT < 23) return true;
        return Settings.canDrawOverlays(this);
    }

    // Android 10+ menolak akses clipboard untuk app background dan mencatatnya di logcat:
    // "Denying clipboard access to <paket>, application is not in focus nor is it a system service".
    // Begitu baris itu muncul, kita buka activity transparan sesaat supaya app punya fokus,
    // lalu clipboard dibaca di sana.
    void watchLogcat() {
        final String needle = "Denying clipboard access to " + getPackageName();
        while (running) {
            BufferedReader r = null;
            try {
                logProc = Runtime.getRuntime().exec(new String[]{"logcat", "-T", "1", "-v", "brief", "-s", "ClipboardService"});
                r = new BufferedReader(new InputStreamReader(logProc.getInputStream()));
                String line;
                while (running && (line = r.readLine()) != null) {
                    if (line.indexOf(needle) >= 0) {
                        long now = SystemClock.elapsedRealtime();
                        if (now < ignoreUntil) continue;
                        if (now - lastFocusTry < 700) continue;
                        lastFocusTry = now;
                        main.post(new Runnable() {
                            @Override
                            public void run() {
                                openFocusActivity();
                            }
                        });
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            try {
                if (r != null) r.close();
            } catch (Exception e) {
            }
            try {
                if (logProc != null) logProc.destroy();
            } catch (Exception e) {
            }
            if (!running) break;
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                break;
            }
        }
    }

    void openFocusActivity() {
        try {
            Intent i = new Intent(this, FocusActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                    | Intent.FLAG_ACTIVITY_NO_ANIMATION
                    | Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS);
            startActivity(i);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    Notification buildNotif() {
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel("clip", "Clip Sync", NotificationManager.IMPORTANCE_LOW));
            b = new Notification.Builder(this, "clip");
        } else {
            b = new Notification.Builder(this);
        }
        String info;
        if (!hasReadLogs()) {
            info = "READ_LOGS belum diberikan: kirim clipboard hanya jalan saat app dibuka";
        } else if (!canDrawOverlay()) {
            info = "Izin 'tampil di atas app lain' belum aktif";
        } else {
            info = "Siap sinkron di background";
        }
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, MainActivity.class),
                Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
        b.setContentTitle("Clip Sync aktif")
                .setContentText(info)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentIntent(pi)
                .setOngoing(true);
        return b.build();
    }

    void send(final String text) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                DatagramSocket s = null;
                try {
                    byte[] data = (KEY + text).getBytes("UTF-8");
                    if (data.length > 65000) return;
                    s = new DatagramSocket();
                    s.setBroadcast(true);
                    s.send(new DatagramPacket(data, data.length, InetAddress.getByName("255.255.255.255"), PORT));
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    if (s != null) s.close();
                }
            }
        }).start();
    }

    // Terima dari HP lain. Kalau error (mis. Wi-Fi putus/ganti), coba lagi otomatis.
    void receive() {
        byte[] buf = new byte[65507];
        while (running) {
            try {
                sock = new DatagramSocket(null);
                sock.setReuseAddress(true);
                sock.bind(new InetSocketAddress(PORT));
                while (running && !sock.isClosed()) {
                    DatagramPacket p = new DatagramPacket(buf, buf.length);
                    sock.receive(p);
                    String s = new String(p.getData(), 0, p.getLength(), "UTF-8");
                    if (!s.startsWith(KEY)) continue;
                    final String t = s.substring(KEY.length());
                    if (t.equals(last)) continue;
                    last = t;
                    // setPrimaryClip akan memicu listener; jangan buka activity fokus untuk itu
                    ignoreUntil = SystemClock.elapsedRealtime() + 2000;
                    main.post(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                cm.setPrimaryClip(ClipData.newPlainText("sync", t));
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
                }
            } catch (Exception e) {
                if (running) e.printStackTrace();
            }
            try {
                if (sock != null) sock.close();
            } catch (Exception e) {
            }
            if (!running) break;
            try {
                Thread.sleep(3000);
            } catch (InterruptedException e) {
                break;
            }
        }
    }

    // Kalau app di-swipe dari recents, jadwalkan start ulang
    @Override
    public void onTaskRemoved(Intent rootIntent) {
        try {
            Intent i = new Intent(getApplicationContext(), ClipService.class);
            i.setPackage(getPackageName());
            android.app.AlarmManager am = (android.app.AlarmManager) getSystemService(Context.ALARM_SERVICE);
            PendingIntent pi;
            if (Build.VERSION.SDK_INT >= 26) {
                pi = PendingIntent.getForegroundService(this, 1, i, PendingIntent.FLAG_ONE_SHOT | PendingIntent.FLAG_IMMUTABLE);
            } else {
                pi = PendingIntent.getService(this, 1, i, PendingIntent.FLAG_ONE_SHOT);
            }
            am.set(android.app.AlarmManager.ELAPSED_REALTIME, SystemClock.elapsedRealtime() + 1500, pi);
        } catch (Exception e) {
            e.printStackTrace();
        }
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        running = false;
        try {
            cm.removePrimaryClipChangedListener(listener);
        } catch (Exception e) {
        }
        try {
            if (sock != null) sock.close();
        } catch (Exception e) {
        }
        try {
            if (logProc != null) logProc.destroy();
        } catch (Exception e) {
        }
        try {
            if (lock != null && lock.isHeld()) lock.release();
            if (wifiLock != null && wifiLock.isHeld()) wifiLock.release();
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        } catch (Exception e) {
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
