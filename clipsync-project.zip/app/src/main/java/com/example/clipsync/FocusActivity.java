package com.example.clipsync;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

// Activity transparan yang cuma hidup sebentar: begitu dapat fokus,
// Android mengizinkan app membaca clipboard.
public class FocusActivity extends Activity {

    boolean done = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        // Pengaman: tutup sendiri kalau fokus tidak pernah datang
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                finish();
            }
        }, 1500);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus && !done) {
            done = true;
            try {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData d = cm.getPrimaryClip();
                if (d != null && d.getItemCount() > 0) {
                    CharSequence cs = d.getItemAt(0).coerceToText(this);
                    if (cs != null) {
                        Intent i = new Intent(this, ClipService.class);
                        i.setAction(ClipService.ACTION_SEND);
                        i.putExtra(ClipService.EXTRA_TEXT, cs.toString());
                        startService(i);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            finish();
            overridePendingTransition(0, 0);
        }
    }
}
