package com.example.clipsync;

import android.content.ClipData;
import android.os.IBinder;
import android.util.Base64;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

// Dijalankan lewat app_process sebagai uid shell (2000), BUKAN sebagai bagian dari aplikasi.
// Shell punya izin READ_CLIPBOARD_IN_BACKGROUND, jadi boleh membaca clipboard tanpa fokus.
// Keluaran (stdout), satu baris per kejadian:
//   READY uid=<uid>     siap
//   C <base64>          teks clipboard berubah
//   H                   detak (supaya proses yatim bisa mati sendiri)
//   ERR <pesan>         gagal
public class ClipHelper {

    static Object clipboard;
    static Method getClip;
    static Object[] clipArgs;

    static void say(String s) {
        System.out.println(s);
        System.out.flush();
        // induk (aplikasi) sudah mati -> pipa putus -> keluar
        if (System.out.checkError()) System.exit(0);
    }

    // Isi argumen getPrimaryClip sesuai versi Android (jumlah parameternya berbeda-beda)
    static Object[] buildArgs(Method m) {
        Class<?>[] p = m.getParameterTypes();
        Object[] a = new Object[p.length];
        int strings = 0;
        for (int i = 0; i < p.length; i++) {
            if (p[i] == String.class) {
                a[i] = (strings == 0) ? "com.android.shell" : null; // nama paket, lalu attributionTag
                strings++;
            } else if (p[i] == int.class) {
                a[i] = Integer.valueOf(0);                          // userId, deviceId
            } else if (p[i] == long.class) {
                a[i] = Long.valueOf(0L);
            } else if (p[i] == boolean.class) {
                a[i] = Boolean.FALSE;
            } else {
                a[i] = null;
            }
        }
        return a;
    }

    static String readText() throws Exception {
        Object clip = getClip.invoke(clipboard, clipArgs);
        if (clip == null) return null;
        ClipData cd = (ClipData) clip;
        if (cd.getItemCount() == 0) return null;
        CharSequence cs = cd.getItemAt(0).getText();
        return cs == null ? null : cs.toString();
    }

    public static void main(String[] args) {
        try {
            Class<?> sm = Class.forName("android.os.ServiceManager");
            IBinder b = (IBinder) sm.getMethod("getService", String.class).invoke(null, "clipboard");
            if (b == null) {
                say("ERR service clipboard tidak ditemukan");
                return;
            }
            Class<?> stub = Class.forName("android.content.IClipboard$Stub");
            clipboard = stub.getMethod("asInterface", IBinder.class).invoke(null, b);
            Class<?> iface = Class.forName("android.content.IClipboard");
            for (Method m : iface.getMethods()) {
                if (m.getName().equals("getPrimaryClip")) {
                    getClip = m;
                    break;
                }
            }
            if (getClip == null) {
                say("ERR getPrimaryClip tidak ada");
                return;
            }
            clipArgs = buildArgs(getClip);
        } catch (Throwable t) {
            say("ERR init: " + t);
            return;
        }

        say("READY uid=" + android.os.Process.myUid());

        String lastText = null;
        boolean first = true;
        int beat = 0;
        while (true) {
            try {
                String text = readText();
                if (first) {
                    lastText = text; // isi awal tidak dikirim, hanya perubahan berikutnya
                    first = false;
                } else if (text != null && text.length() > 0 && !text.equals(lastText)) {
                    lastText = text;
                    say("C " + Base64.encodeToString(text.getBytes("UTF-8"), Base64.NO_WRAP));
                }
            } catch (InvocationTargetException e) {
                Throwable c = (e.getCause() != null) ? e.getCause() : e;
                say("ERR baca: " + c);
                return;
            } catch (Throwable t) {
                say("ERR " + t);
                return;
            }
            beat++;
            if (beat >= 30) { // sekitar 10 detik
                beat = 0;
                say("H");
            }
            try {
                Thread.sleep(350);
            } catch (InterruptedException e) {
                return;
            }
        }
    }
}
